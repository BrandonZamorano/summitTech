#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>

#include "movieAccount.h"

using namespace std;

void printSubscriptionPlans();
void menu();
void subMenu();
void registerAccount(vector<movieAccount>& accounts);
void printCustomerData(const vector<movieAccount>& accounts);
int search(const vector<movieAccount>& accounts, int accNum);
void processCustomer(vector<movieAccount>& accounts, int accNum, vector<string>& listOfMovies);
void purchasePlan(vector<movieAccount>& accounts, int planNum);
void loadMovies(vector<string>& movieList);
void displayAllMovies(const vector<string>& movieList);
void movieMenu(const vector<string>& movieList);
void displayByGenre(const vector<string>& movieList);
int movieNum = 0;
int main()
{
	vector<movieAccount> accountVector;
	vector<string>listOfMovies;
	int accNum;
	int choice;

	loadMovies(listOfMovies);
	//displayAllMovies(listOfMovies);
	menu();
	cin >> choice;
	cout << endl;
	//keeps the program running until user wishes to quit
	while (choice != 9) // while user doesn't want to quit...
	{
		switch (choice)
		{
			case 1:
				cout << "Adding customer..." << endl;
				registerAccount(accountVector);
				break;
			case 2:
				cout << "Enter account number: ";
				cin >> accNum;
				cout << endl;
				cout << "Processing Customer." << endl;
				processCustomer(accountVector, accNum, listOfMovies);
				break;
			case 3:
				cout << "Printing customer data." << endl;
				printCustomerData(accountVector);
				cout << endl;
				break;
			default:
				cout << "Invalid choice." << endl;
		}
		menu();
		cin >> choice;
		cout << endl;
	}
	cout << "Goodbye!" << endl;
	//registerAccount(name, initialAmount, accountVector);
	return 0;
}

void menu()
{
	cout << "1. Enter 1 to create a new account." << endl;
	cout << "2. Enter 2 to process customer" << endl;
	cout << "3. Enter 3 to print customer data." << endl;
	cout << "9. Enter 9 to exit the program." << endl;
}
void subMenu()
{
	cout << "1. Enter 1 to check out a movie. " << endl;
	cout << "2. Enter 2 to remove a movie." << endl;
	cout << "3. Enter 3 to check number of movies" << endl;
	cout << "4. Enter 4 to check your current movie list." << endl;
	cout << "5. Enter 5 to change your name." << endl;
	cout << "6. Enter 6 to add funds to your account" << endl;
	cout << "7. Enter 7 to change subscription plan" << endl;
	cout << "9. Enter 9 to exit sub-Menu." << endl;
}

// sets account data from user input info
void registerAccount(vector<movieAccount>& accounts)
{
	int choice;
	movieAccount account;
	double initialAmount;
	string name;
	cout << "Enter first name: ";
	cin.ignore();
	getline(cin, name);
	cout << endl;
	account.setName(name); //sets the name for new account
	cout << "Welcome, " << name << ", to our crappy netflix knock-off!" << endl << endl;
	cout << "We need to set up your account first." << endl << endl;
	cout << "To get started, add to your balance and purchase a subscription plan." << endl << endl;
	cout << "Here are the subscription plans we offer: " << endl << endl;
	printSubscriptionPlans(); // prints out the subscription plans
	cout << "Enter amount to add to balance: $";
	cin >> initialAmount;
	account.setBalance(initialAmount);//sets the balance of the new account
	cout << "Great! You have $" << initialAmount << " to your account." << endl;
	accounts.push_back(account);//adds the account to the accountVector

	cout << "Enter the number for the subscription plan you wish to buy." << endl;
	cin >> choice;
	cout << endl;
	purchasePlan(accounts, choice);

}
//displays the subscription plans.
void printSubscriptionPlans()
{
	string subscriptions[3][4] =
	{
		{ "Basic", "10", "SD", "5" },
		{ "Standard", "15", "HD", "15" },
		{ "Premium", "20", "UHD", "Unlimited" }

	};

	for (int row = 0; row < 3; row++)
	{
		cout << row + 1 << '.' << subscriptions[row][0] << " $" << subscriptions[row][1] << " " << subscriptions[row][2]
			<< " " << subscriptions[row][3] << endl;
		cout << setw(subscriptions[row][0].length() + 5 + subscriptions[row][2].length() + 3 + subscriptions[row][3].length()) << setfill('-') << "-" << endl;
		cout << endl;
	}
}
void printCustomerData(const vector<movieAccount>& accounts)
{
	for (movieAccount account : accounts)
	{
		account.print();
		cout << endl;
	}
}
int search(const vector<movieAccount>& accounts, int accNum)
{
	int length = accounts.size(); //static_cast<signed int>(accounts.size());
	for (unsigned int i = 0; i < length; i++)
	{
		if (accounts[i].getAccountNumber() == accNum)
		{
			return i;
		}
	}

	return -1;
}
void processCustomer(vector<movieAccount>& accounts, int accNum, vector<string>& listOfMovies)
{
	double amount = 0.0;
	int choice = 0;
	int index = search(accounts, accNum);
	string newName;

	if (index != -1)
	{
		subMenu();
		int selection = 0;
		double amount = 0;
		cin >> selection;
		while (selection != 9)
		{
			switch (selection)
			{
				case 1:
					cout << "Chose checkout movie" << endl;
					if (accounts[index].getCanCheckOut())
					{
						cout << "You can check out movies." << endl;
						movieMenu(listOfMovies);
						cout << "Enter the number to select the movie: " << endl;
						cin >> movieNum;

						for (int index = 0; index < static_cast<signed int>(listOfMovies.size()); index++)
						{
							if (index + 1 == movieNum)
								accounts[index].checkOut(listOfMovies[index].substr(0, listOfMovies[index].find(",")));
						}
					}
					else
					{
						cout << "You cannot check out any more movies.";
					}
					break;
				case 2:
					cout << "Chose to remove a movie" << endl;
					break;
				case 3:
					cout << "Chose to check number of movies" << endl;
					cout << "Currently have: " << accounts[index].getNumOfMovies()
						<< " movies." << endl;
					cout << endl;
				case 4:
					cout << "Chose to check current list of movies" << endl;
					cout << "Here are the movies you have checked out: " << endl;
					accounts[index].printMyMovies();

					break;
				case 5:
					cout << "Chose to change name." << endl;
					cout << "What do you wish to change it to?" << endl;
					cin.ignore();
					getline(cin, newName);
					accounts[index].setName(newName);//changes name of specific acc
					break;
				case 6:
					cout << "Chose to add funds." << endl;
					cout << "How much would you like to add?" << endl <<
						"$";
					cin >> amount;
					accounts[index].addBalance(amount);
					break;
				case 7:
					cout << "Your current subscription plan is: " <<
						accounts[index].printSub() << endl;
					cout << "What would you like to change it to?" << endl;
					printSubscriptionPlans();
					cout << "Enter the number for the subscription plan you wish to buy." << endl;
					cin >> choice;
					cout << endl;
					purchasePlan(accounts, choice);
					break;

				default:
					cout << "Invalid choice, bub." << endl;

			}//end of switch
			subMenu();
			cin >> selection;
			cout << endl;
		}// end of while
	}//end of if
	else
	{
		cout << "Invalid ID" << endl;
	}
}
void purchasePlan(vector<movieAccount>& accounts, int planNum)
{
	int newAccount = static_cast<signed int>(accounts.size() - 1);
	switch (planNum)
	{
		case 1:
			if (accounts[newAccount].getBalance() >= 10)
			{
				cout << "You chose the Basic plan." << endl;
				accounts[newAccount].withdraw(10.00);
				// sets the subscription to BASIC
				accounts[newAccount].setSubscription(1);
				// user can now checkout movies
				accounts[newAccount].setCanCheckOut(true);

			}
			else
			{
				cout << "Insufficient funds.";
			}
			break;
		case 2:
			if (accounts[newAccount].getBalance() >= 15)
			{
				cout << "You chose the Standard plan." << endl;
				accounts[newAccount].withdraw(15.00);
				// sets the subscription to BASIC
				accounts[newAccount].setSubscription(2);
				// user can now checkout movies
				accounts[newAccount].setCanCheckOut(true);

			}
			else
			{
				cout << "Insufficient funds.";
			}
			break;
		case 3:

			if (accounts[newAccount].getBalance() >= 20)
			{
				cout << "You chose the Premium plan." << endl;
				accounts[newAccount].withdraw(20.00);
				// sets the subscription to Premium
				accounts[newAccount].setSubscription(3);
				// user can now checkout movies
				accounts[newAccount].setCanCheckOut(true);

			}
			else
			{
				cout << "Insufficient funds.";
			}
			break;

	}
}
//puts the info into the vector
void loadMovies(vector<string>& movieList)
{
	string lineHolder;
	ifstream inFile;
	inFile.open("movieList.txt");
	if (!inFile)
		cout << "Error opening file" << endl;
	while (!inFile.eof())
	{
		getline(inFile, lineHolder);
		movieList.push_back(lineHolder);

	}
	inFile.close();

}
void displayAllMovies(const vector<string>& movieList)
{
	int firstComma = 0;
	int secondComma = 0;
	int length = static_cast<signed int>(movieList.size());
	for (int index = 0; index < length; index++)
	{
		cout << index + 1 << ". " << movieList[index].substr(0, movieList[index].find(",")) << endl;
	}
}
void movieMenu(const vector<string>& movieList)
{
	int choice = 0;
	cout << "1. Enter 1 to display all movies" << endl;
	cout << "2. Enter 2 to display movies by genre." << endl;
	cin >> choice;
	cout << endl;

	switch (choice)
	{
		case 1:
			cout << "Chose to display all: " << endl;
			displayAllMovies(movieList);
			break;
		case 2:
			cout << "Chose to display by genre." << endl;
			displayByGenre(movieList);
			
	}
}

void displayByGenre(const vector<string>& movieList)
{
	int length = static_cast<signed int>(movieList.size());
	vector<string> movieGenre;
	int choice = 0;

	cout << "What do genre do you wish to sort by?" << endl;
	cout << "1. Enter 1 to sort by Fantasy" << endl;
	cout << "2. Enter 2 to sort by Sci-Fi" << endl;
	cout << "3. Enter 3 to sort by Adventure" << endl;
	cout << "4. Enter 4 to sort by Action" << endl;
	cout << "5. Enter 5 to sort by Drama" << endl;
	cout << "6. Enter 6 to sort by Disaster" << endl;
	cout << "7. Enter 7 to sort by Crime" << endl;
	cin >> choice;

	switch (choice)
	{
		case 1:
			for (int index = 0; index < length; index++)
			{
				//Currently displays genre,movielength
				string genre = movieList[index].substr(movieList[index].find(",") + 1);
				//displays only the genre now
				genre = genre.substr(0, genre.find(","));
				//movieName = movieList[index].substr(movieList[index].find(",") + 1, movieList[index].find(",") - movieName.length());
				//cout << genre << endl;
				if (genre == "Fantasy")
					movieGenre.push_back(movieList[index].substr(0, movieList[index].find(",")));
			}
			for (unsigned int index = 0; index < movieGenre.size(); index++)
			{
				cout << index + 1 << ". " << movieGenre[index] << endl;
			}
			cout << endl;
			movieGenre.clear();
			break;
		case 2:
			for (int index = 0; index < length; index++)
			{
				//Currently displays genre,movielength
				string genre = movieList[index].substr(movieList[index].find(",") + 1);
				//displays only the genre now
				genre = genre.substr(0, genre.find(","));
				//movieName = movieList[index].substr(movieList[index].find(",") + 1, movieList[index].find(",") - movieName.length());
				//cout << genre << endl;
				if (genre == "Sci-Fi")
					movieGenre.push_back(movieList[index].substr(0, movieList[index].find(",")));
			}
			for (unsigned int index = 0; index < movieGenre.size(); index++)
			{
				cout << index + 1 << ". " << movieGenre[index] << endl;
			}
			cout << endl;
			movieGenre.clear();
			break;
		case 3:
			for (int index = 0; index < length; index++)
			{
				//Currently displays genre,movielength
				string genre = movieList[index].substr(movieList[index].find(",") + 1);
				//displays only the genre now
				genre = genre.substr(0, genre.find(","));
				//movieName = movieList[index].substr(movieList[index].find(",") + 1, movieList[index].find(",") - movieName.length());
				//cout << genre << endl;
				if (genre == "Adventure")
					movieGenre.push_back(movieList[index].substr(0, movieList[index].find(",")));
			}
			for (unsigned int index = 0; index < movieGenre.size(); index++)
			{
				cout << index + 1 << ". " << movieGenre[index] << endl;
			}
			cout << endl;
			movieGenre.clear();
			break;
		case 4:
			for (int index = 0; index < length; index++)
			{
				//Currently displays genre,movielength
				string genre = movieList[index].substr(movieList[index].find(",") + 1);
				//displays only the genre now
				genre = genre.substr(0, genre.find(","));
				//movieName = movieList[index].substr(movieList[index].find(",") + 1, movieList[index].find(",") - movieName.length());
				//cout << genre << endl;
				if (genre == "Action")
					movieGenre.push_back(movieList[index].substr(0, movieList[index].find(",")));
			}
			for (unsigned int index = 0; index < movieGenre.size(); index++)
			{
				cout << index + 1 << ". " << movieGenre[index] << endl;
			}
			cout << endl;
			movieGenre.clear();
			break;
		case 5:
			for (int index = 0; index < length; index++)
			{
				//Currently displays genre,movielength
				string genre = movieList[index].substr(movieList[index].find(",") + 1);
				//displays only the genre now
				genre = genre.substr(0, genre.find(","));
				//movieName = movieList[index].substr(movieList[index].find(",") + 1, movieList[index].find(",") - movieName.length());
				//cout << genre << endl;
				if (genre == "Drama")
					movieGenre.push_back(movieList[index].substr(0, movieList[index].find(",")));
			}
			for (unsigned int index = 0; index < movieGenre.size(); index++)
			{
				cout << index + 1 << ". " << movieGenre[index] << endl;
			}
			cout << endl;
			movieGenre.clear();
			break;
		case 6:
			for (int index = 0; index < length; index++)
			{
				//Currently displays genre,movielength
				string genre = movieList[index].substr(movieList[index].find(",") + 1);
				//displays only the genre now
				genre = genre.substr(0, genre.find(","));
				//movieName = movieList[index].substr(movieList[index].find(",") + 1, movieList[index].find(",") - movieName.length());
				//cout << genre << endl;
				if (genre == "Disaster")
					movieGenre.push_back(movieList[index].substr(0, movieList[index].find(",")));
			}
			for (unsigned int index = 0; index < movieGenre.size(); index++)
			{
				cout << index + 1 << ". " << movieGenre[index] << endl;
			}
			cout << endl;
			movieGenre.clear();
			break;
		case 7:
			for (int index = 0; index < length; index++)
			{
				//Currently displays genre,movielength
				string genre = movieList[index].substr(movieList[index].find(",") + 1);
				//displays only the genre now
				genre = genre.substr(0, genre.find(","));
				//movieName = movieList[index].substr(movieList[index].find(",") + 1, movieList[index].find(",") - movieName.length());
				//cout << genre << endl;
				if (genre == "Crime")
					movieGenre.push_back(movieList[index].substr(0, movieList[index].find(",")));
			}
			for (unsigned int index = 0; index < movieGenre.size(); index++)
			{
				cout << index + 1 << ". " << movieGenre[index] << endl;
			}
			cout << endl;
			movieGenre.clear();
			break;

	}// end of switch
	

}/*
string getMovieGenre(const vector<string>& movieList)
{
	int length = static_cast<signed int>(movieList.size());

}*/