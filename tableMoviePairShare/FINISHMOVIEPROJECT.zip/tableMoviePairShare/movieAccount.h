#include <iostream>
#include <vector>
#include <string>


using namespace std;

#ifndef MOVIEACCOUNT_H
#define MOVIEACCOUNT_H


class movieAccount
{
public:
	enum subType { NONE, BASIC, STANDARD, PREMIUM };
	//Default Constructor
	movieAccount();
	//Overload Constructor
	movieAccount(string, subType, double, bool);

	string getName() const;
	double getBalance() const;
	int getAccountNumber() const;
	int getNumOfMovies() const;
	bool getCanCheckOut() const;
	subType getSubscription() const;


	void setName(string name);
	void setBalance(double amount);
	void setNumOfMovies(int numMovies);
	void setSubscription(int sub);
	void addBalance(double amount);
	void withdraw(double amount);
	void setCanCheckOut(bool value);
	string printSub() const;
	void print() const;
	void printMyMovies() const;
	void checkOut(string movieName);

	//Destructor
	~movieAccount();
private:
	static int num;
	int accountNumber;
	string accountName;
	subType subscription;
	int numOfMovies;
	double balance;
	vector<string> movieList;
	bool canCheckOut;
};

#endif