/*
Group Members: Brandon Zamorano, Cole Perry, Micheal Walburn, Ss
*/
#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>

#include "movieAccount.h"

using namespace std;

void printSubscriptionPlans(); // Prints the subscription plans
void menu(); // Prints the main menu
void subMenu(); // Prints the subMenu
void registerAccount(vector<movieAccount>& accounts); //Guides user into making an account and makes account based on user input.
void printCustomerData(const vector<movieAccount>& accounts); //Prints all the accounts registed along with their data.
int search(const vector<movieAccount>& accounts, int accNum); //Searches for an account number, if found it returns the index of the account in the vector.
void processCustomer(vector<movieAccount>& accounts, int accNum, vector<string>& listOfMovies); //
void purchasePlan(vector<movieAccount>& accounts, int planNum, int accNum); //Purchases subscription plan if enough funds, applies it to the account, set checkout to true
void loadMovies(vector<string>& movieList); //Loads the contents of the "movieList.txt" to the vector "listOfMovies"
void displayAllMovies(const vector<string>& movieList); // Displays the movie titles available.
int movieNum = 0; // global variable that will be set from a function

int main()
{
	vector<movieAccount> accountVector; //Movie account vector that holds accounts
	vector<string>listOfMovies; //String vector that holds movie info
	int accNum = 0; 
	int choice = 0;
	int x = 0; //screenholder

	loadMovies(listOfMovies); // First, load the movie data in.
	menu(); // Then display the main menu
	cin >> choice; // grab user choice
	cout << endl;
	//keeps the program running until user wishes to quit (user didn't choose 9)
	while (choice != 9) // while user doesn't want to quit...
	{
		switch (choice)
		{
			case 1:
				cout << "Adding customer..." << endl;
				registerAccount(accountVector);
				break;
			case 2:
				cout << "Enter account number: ";
				cin >> accNum;
				cout << endl;
				cout << "Processing Customer." << endl;
				processCustomer(accountVector, accNum, listOfMovies);
				break;
			case 3:
				cout << "Printing customer data." << endl;
				printCustomerData(accountVector);
				cout << endl;
				break;
			default:
				cout << "Invalid choice." << endl;
		}
		menu();
		cin >> choice;
		cout << endl;
	}
	cout << "Goodbye!" << endl; // Ye old friendly goodbye. 
	cin >> x; // holds the screen
	return 0;
}

void menu()
{
	cout << "1. Enter 1 to create a new account." << endl;
	cout << "2. Enter 2 to process customer" << endl;
	cout << "3. Enter 3 to print customer data." << endl;
	cout << "9. Enter 9 to exit the program." << endl;
}
void subMenu()
{
	cout << "1. Enter 1 to check out a movie. " << endl;
	cout << "2. Enter 2 to remove a movie." << endl;
	cout << "3. Enter 3 to check number of movies" << endl;
	cout << "4. Enter 4 to check your current movie list." << endl;
	cout << "5. Enter 5 to change your name." << endl;
	cout << "6. Enter 6 to add funds to your account" << endl;
	cout << "7. Enter 7 to change subscription plan" << endl;
	cout << "9. Enter 9 to exit sub-Menu." << endl;
}

// sets account data from user input info
void registerAccount(vector<movieAccount>& accounts)
{
	int choice;
	movieAccount account;
	double initialAmount;
	string name;
	cout << "Enter name: ";
	cin.ignore();
	getline(cin, name);
	cout << endl;
	account.setName(name); //sets the name for new account
	cout << "Welcome, " << name << ", to our crappy netflix knock-off!" << endl << endl;
	cout << "We need to set up your account first." << endl << endl;
	cout << "To get started, add to your balance and purchase a subscription plan." << endl << endl;
	cout << "Here are the subscription plans we offer: " << endl << endl;
	printSubscriptionPlans(); // prints out the subscription plans
	cout << "Enter amount to add to balance: $";
	cin >> initialAmount;
	account.setBalance(initialAmount);//sets the balance of the new account
	cout << "Great! You have $" << initialAmount << " to your account." << endl;
	accounts.push_back(account);//adds the account to the accountVector

	cout << "Enter the number for the subscription plan you wish to buy." << endl;
	cin >> choice;
	cout << endl;
	purchasePlan(accounts, choice, accounts[static_cast<signed int>(accounts.size()) - 1].getAccountNumber());

}
//displays the subscription plans.
void printSubscriptionPlans()
{
	string subscriptions[3][4] =
	{//      0      1     2     3
		{ "Basic", "10", "SD", "5" },
		{ "Standard", "15", "HD", "15" },
		{ "Premium", "20", "UHD", "Unlimited" }

	};
	// Below prints the array, somewhat formatted.
	for (int row = 0; row < 3; row++)
	{
		cout << row + 1 << '.' << subscriptions[row][0] << " $" << subscriptions[row][1] << " " << subscriptions[row][2]
			<< " " << subscriptions[row][3] << endl;
		cout << setw(subscriptions[row][0].length() + 5 + subscriptions[row][2].length() + 3 + subscriptions[row][3].length()) << setfill('-') << "-" << endl;
		cout << endl;
	}
}
void printCustomerData(const vector<movieAccount>& accounts)
{
	for (movieAccount account : accounts) // for ranged loop, basically goes over all the accounts and will use the member function Pint()
	{
		account.print();
		cout << endl;
	}
}
int search(const vector<movieAccount>& accounts, int accNum)
{
	int length = static_cast<signed int>(accounts.size()); // convert to signed int to prevent warning because .size() returns unsigned int
	for ( int i = 0; i < length; i++)
	{
		if (accounts[i].getAccountNumber() == accNum)
		{
			return i;
		}
	}

	return -1;
}
void processCustomer(vector<movieAccount>& accounts, int accNum, vector<string>& listOfMovies)
{
	double amount = 0.0;
	int choice = 0;
	int index = search(accounts, accNum);
	string newName;

	if (index != -1)
	{
		subMenu();
		int selection = 0;
		double amount = 0;
		cin >> selection;
		while (selection != 9)
		{
			switch (selection)
			{
				case 1:
					cout << "Chose checkout movie" << endl;
					if (accounts[index].getCanCheckOut()) // checks if the user can checkout movies
					{
						cout << "You can check out movies." << endl;
						displayAllMovies(listOfMovies);
						cout << "Enter the number to select the movie: " << endl;
						cin >> movieNum; // uses the global variable to store selection 

						for (int idx = 0; idx < static_cast<signed int>(listOfMovies.size()); idx++) //loops over the movie list
						{
							if (idx + 1 == movieNum) // finds the one that the user chose
								accounts[index].checkOut(listOfMovies[idx].substr(0, listOfMovies[idx].find(","))); //checks out the movie
								// checkOut's arguments basically just get the movie's title 
						}
					}
					else
					{
						cout << "You cannot check out any more movies." << endl;
					}
					break;
				case 2:
					cout << "Chose to remove a movie" << endl;
					accounts[index].printMyMovies();
					cout << "Enter a number to select a movie to remove: " << endl;
					cin >> movieNum;
					accounts[index].returnMovie(movieNum);
					break;
				case 3:
					cout << "Chose to check number of movies" << endl;
					cout << "Currently have: " << accounts[index].getNumOfMovies()
						<< " movies." << endl;
					cout << endl;
					break;
				case 4:
					cout << "Chose to check current list of movies" << endl;
					cout << "Here are the movies you have checked out: " << endl;
					cout << "-----------------------------------------" << endl;
					accounts[index].printMyMovies();
					cout << endl;

					break;
				case 5:
					cout << "Chose to change name." << endl;
					cout << "What do you wish to change it to?" << endl;
					cin.ignore();
					getline(cin, newName);
					accounts[index].setName(newName);//changes name of specific acc
					break;
				case 6:
					cout << "Chose to add funds." << endl;
					cout << "How much would you like to add?" << endl <<
						"$";
					cin >> amount;
					accounts[index].addBalance(amount);
					break;
				case 7:
					cout << "Your current subscription plan is: " <<
						accounts[index].printSub() << endl;
					cout << "What would you like to change it to?" << endl;
					printSubscriptionPlans();
					cout << "Enter the number for the subscription plan you wish to buy." << endl;
					cin >> choice;
					cout << endl;
					purchasePlan(accounts, choice, accNum);
					break;

				default:
					cout << "Invalid choice, bub." << endl;

			}//end of switch
			subMenu();
			cin >> selection;
			cout << endl;
		}// end of while
	}//end of if
	else
	{
		cout << "Invalid ID" << endl;
	}
}
void purchasePlan(vector<movieAccount>& accounts, int planNum, int accNum)
{
	int acc = 0;
	for (unsigned int i = 0; i < accounts.size(); i++)
	{
		if (accounts[i].getAccountNumber() == accNum)
		{
			acc = i;
		}
	}
	switch (planNum)
	{
		case 1:
			if (accounts[acc].getBalance() >= 10)
			{
				cout << "You chose the Basic plan." << endl;
				accounts[acc].withdraw(10.00);
				// sets the subscription to BASIC
				accounts[acc].setSubscription(1);
				// user can now checkout movies
				accounts[acc].setCanCheckOut(true);

			}
			else
			{
				cout << "Insufficient funds." << endl;
			}
			break;
		case 2:
			if (accounts[acc].getBalance() >= 15)
			{
				cout << "You chose the Standard plan." << endl;
				accounts[acc].withdraw(15.00);
				// sets the subscription to BASIC
				accounts[acc].setSubscription(2);
				// user can now checkout movies
				accounts[acc].setCanCheckOut(true);

			}
			else
			{
				cout << "Insufficient funds.";
			}
			break;
		case 3:

			if (accounts[acc].getBalance() >= 20)
			{
				cout << "You chose the Premium plan." << endl;
				accounts[acc].withdraw(20.00);
				// sets the subscription to Premium
				accounts[acc].setSubscription(3);
				// user can now checkout movies
				accounts[acc].setCanCheckOut(true);

			}
			else
			{
				cout << "Insufficient funds.";
			}
			break;

	}
}
//puts the info into the vector
void loadMovies(vector<string>& movieList)
{
	string lineHolder;
	ifstream inFile;
	inFile.open("movieList.txt");
	if (!inFile)
		cout << "Error opening file" << endl;
	while (!inFile.eof())
	{
		getline(inFile, lineHolder);
		movieList.push_back(lineHolder);

	}
	inFile.close();

}
void displayAllMovies(const vector<string>& movieList)
{
	int length = static_cast<signed int>(movieList.size()); // converts to signed int to prevent any warnings (just in case)
	for (int index = 0; index < length; index++)
	{
		cout << index + 1 << ". " << movieList[index].substr(0, movieList[index].find(",")) << endl;
		// prints the movie titles from the text file formatted like this:
		// 1. "First Movie"
		// 2. "Second Movie"
	}
}
