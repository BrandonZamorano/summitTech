#include "movieAccount.h"
#include <iomanip>

int movieAccount::num = 100; // Account Numbers will go by 100's,next account will be 200, etc.

movieAccount::movieAccount() // default constructor
{
	accountNumber = num;
	num = num + 100;
	accountName = " ";
	subscription = NONE;
	numOfMovies = 0;
	balance = 0.0;
	canCheckOut = false;
}

movieAccount::movieAccount(string name,
	subType sub, double bal, bool checkout) // overload constructor
{
	accountNumber = num;
	num = num + 100;
	accountName = name;
	subscription = sub;
	balance = bal;
	canCheckOut = false;
}

string movieAccount::getName() const
{
	return accountName;
}

double movieAccount::getBalance() const
{
	return balance;
}

int movieAccount::getAccountNumber() const
{
	return accountNumber;
}

int movieAccount::getNumOfMovies() const
{
	return static_cast<signed int>(movieList.size()); //numOfMovies;
}

bool movieAccount::getCanCheckOut() const
{
	switch (subscription)
	{
		case 0: // Subscription: NONE 
			return false; //Has no subscription, therefore can't check out
		case 1: // Subscription: BASIC
			return (movieList.size() < 5) ? true : false; // If user's movieList size is less than 5 (which is the BASIC's limit), then can check out
			break;
		case 2:// Subscription: STANDARD
			return (movieList.size() < 15) ? true : false;
			break;
		case 3:// Subscription: Premium
			return true; // unlimited so always true
	}

	return false;
}

movieAccount::subType movieAccount::getSubscription() const
{
	return subscription;
}


void movieAccount::setName(string name)
{
	accountName = name;
}

void movieAccount::setBalance(double amount)
{
	balance = amount;
}

void movieAccount::setNumOfMovies(int numMovies)
{
	numOfMovies = numMovies;
}

void movieAccount::setSubscription(int sub)
{
	switch (subscription)
	{
		case 2://Standard plan
			// user wants to downgrade to the basic plan, but the basic plan's limit is 5, so if the user has more than 5 movies account//
			// then any movie past 5 will be removed.
			if (sub == 1 && movieList.size() > 5)
			{
				cout << "Downgraded plan, adjusting movieList size." << endl;
				while(!(movieList.size() <= 5))
				{
					movieList.pop_back();
				}
			}
			
			break;
		case 3: // premium plan
			// user wants to downgrade to the basic plan, but the basic plan's limit is 5, so if the user has more than 5 movies account//
			// then any movie past 5 will be removed.
			if (sub == 1 && movieList.size() > 5)
			{
				cout << "Downgraded plan, adjusting movieList size." << endl;
				while (!(movieList.size() <= 5))
				{
					movieList.pop_back();
				}
			}
			// user wants to downgrade to the standard plan, but the standard's plan limit is 15, so if the user has more than 15 movies checked out//
			// then any movie past 15 will be removed.
			else if (sub == 2 && movieList.size() > 15)
			{
				cout << "Downgraded plan, adjusting movieList size." << endl;
				while (!(movieList.size() <= 15))
				{
					movieList.pop_back();
				}

			}
	}
	// Once the downgrade has been made (if needed), then change the user's subscription
	subscription = static_cast<subType>(sub);

}

void movieAccount::setCanCheckOut(bool value)
{
	canCheckOut = value;
}

void movieAccount::addBalance(double amount)
{
	if (amount > 0) // only add if amount is positive
		balance += amount;
}

void movieAccount::withdraw(double amount)
{
	if (amount > 0) // only subtract positive amount
		balance -= amount;
}

string movieAccount::printSub() const
{
	switch (subscription)
	{
		case 0:
			return  "None";
			break;
		case 1:
			return"Basic";
			break;
		case 2:
			return "Standard";
			break;
		case 3:
			return  "Premium";
			break;
	}
}

void movieAccount::print() const
{

	cout << fixed << showpoint << setprecision(2); // print out with 0's

	cout << "Account Number: " << accountNumber << endl;
	cout << "Account Name: " << accountName << endl;
	cout << "Subscription: " << printSub() << endl;
	cout << "Movies: " << getNumOfMovies() << endl;
	cout << "Balance: " << balance << endl;
	cout << "Can Check Out: " << ((canCheckOut == true) ? "True" : "False") << endl;
	//resets back to defaults
	cout.unsetf(ios::fixed | ios::scientific);
	cout << noshowpoint << setprecision(6);
}

void movieAccount::printMyMovies() const
{
	int idx = 0;
	// prints like: 
	//1. FirstMovie
	//2. SecondMovie
	for (string item : movieList)
	{
		idx += 1;
		cout << idx << ". " << item << endl;
	}
	idx = 0; // resets idx
}
void movieAccount::checkOut(string movieName)
{
	movieList.push_back(movieName); // adds the movie to the vector movieList
}

void movieAccount::returnMovie(int num)
{
	if (num <= movieList.size())
	{
		movieList.erase(movieList.begin() + (num - 1)); // removes selected movie from the movieList Vector.

	}
	else
	{
		cout << "ERROR" << endl;
	}
}

movieAccount::~movieAccount()
{
}
