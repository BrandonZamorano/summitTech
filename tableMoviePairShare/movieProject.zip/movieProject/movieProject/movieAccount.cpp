#include "movieAccount.h"
#include <iomanip>

int movieAccount::num = 100;

movieAccount::movieAccount()
{
	accountNumber = num;
	num = num + 100;
	accountName = " ";
	subscription = NONE;
	numOfMovies = 0;
	balance = 0.0;
	canCheckOut = false;
}

movieAccount::movieAccount(string name,
	subType sub, double bal, bool checkout)
{
	accountNumber = num;
	num = num + 100;
	accountName = name;
	subscription = sub;
	balance = bal;
	canCheckOut = false;
}

string movieAccount::getName() const
{
	return accountName;
}

double movieAccount::getBalance() const
{
	return balance;
}

int movieAccount::getAccountNumber() const
{
	return accountNumber;
}

int movieAccount::getNumOfMovies() const
{
	return static_cast<signed int>(movieList.size()); //numOfMovies;
}

bool movieAccount::getCanCheckOut() const
{
	switch (subscription)
	{
		case 0:
			return false;
		case 1:
			return (movieList.size() < 5) ? true : false;
			break;
		case 2:
			return (movieList.size() < 15) ? true : false;
			break;
		case 3:
			return true; // unlimited so always true
	}

	return false;
}

movieAccount::subType movieAccount::getSubscription() const
{
	return subscription;
}


void movieAccount::setName(string name)
{
	accountName = name;
}

void movieAccount::setBalance(double amount)
{
	balance = amount;
}

void movieAccount::setNumOfMovies(int numMovies)
{
	numOfMovies = numMovies;
}

void movieAccount::setSubscription(int sub)
{
	subscription = static_cast<subType>(sub);
}

void movieAccount::setCanCheckOut(bool value)
{
	canCheckOut = value;
}

void movieAccount::addBalance(double amount)
{
	if (amount > 0) // only add if amount is positive
		balance += amount;
}

void movieAccount::withdraw(double amount)
{
	if (amount > 0) // only subtract positive amount
		balance -= amount;
}

string movieAccount::printSub() const
{
	switch (subscription)
	{
		case 0:
			return  "None";
			break;
		case 1:
			return"Basic";
			break;
		case 2:
			return "Standard";
			break;
		case 3:
			return  "Premium";
			break;
	}
}

void movieAccount::print() const
{

	cout << fixed << showpoint << setprecision(2); // print out with 0's
	
	cout << "Account Number: " << accountNumber << endl;
	cout << "Account Name: " << accountName << endl;
	cout << "Subscription: " << printSub() << endl;
	cout << "Movies: " << getNumOfMovies() << endl;
	cout << "Balance: " << balance << endl;
	cout << "Can Check Out: " << ((canCheckOut == true) ? "True" : "False") << endl;
	//resets back to defaults
	cout.unsetf(ios::fixed | ios::scientific);
	cout << noshowpoint << setprecision(6);
}

movieAccount::~movieAccount()
{
}
